import React from 'react';
import { Polyline } from 'react-leaflet';
import { Node, RiskZone, Environment } from '../../types';
import { computePointRisk } from '../../systems/risk';

interface RiskPathLayerProps {
  path: Node[];
  zones: RiskZone[];
  env: Environment;
  isSelected: boolean;
  getRiskColor: (risk: number) => string;
  type: 'shortest' | 'safest';
  isDashed?: boolean;
}

/**
 * COMPONENT: RiskPathLayer
 * RESPONSIBILITY: Renders a path with segment-based color coding based on risk levels.
 */
export const RiskPathLayer: React.FC<RiskPathLayerProps> = ({ 
  path, zones, env, isSelected, getRiskColor, type, isDashed 
}) => {
  // Use useMemo to avoid re-calculating risk for every node on every map move/zoom
  // We only re-calculate if the path itself, the zones, or the environment change.
  const segments = React.useMemo(() => {
    if (path.length < 2) return [];

    return path.slice(0, -1).map((node, i) => {
      const nextNode = path[i + 1];
      
      // Calculate risk at the midpoint of the segment for consistent coloring with heatmap
      const midLat = (node.lat + nextNode.lat) / 2;
      const midLng = (node.lng + nextNode.lng) / 2;
      const risk = computePointRisk(midLat, midLng, zones, env);
      
      // Shortest path: risk-based gradient (Green -> Red)
      // Safest path: distinct solid color (Safe Green) as a baseline comparison
      const color = type === 'shortest' ? getRiskColor(risk) : '#22c55e';

      return {
        id: `${node.id}-${nextNode.id}`,
        positions: [[node.lat, node.lng], [nextNode.lat, nextNode.lng]] as [number, number][],
        color
      };
    });
  }, [path, zones, env, type, getRiskColor]);

  if (segments.length === 0) return null;

  // Selection styling
  const weight = isSelected ? 8 : 3;
  const opacity = isSelected ? 0.9 : 0.4;
  const zIndex = isSelected ? 1000 : 500;

  return (
    <>
      {segments.map((seg) => (
        <Polyline
          key={seg.id}
          positions={seg.positions}
          pathOptions={{
            color: seg.color,
            weight: weight,
            opacity: opacity,
            dashArray: isDashed ? '10, 10' : undefined,
            lineJoin: 'round',
            lineCap: 'round',
            pane: isSelected ? 'markerPane' : 'overlayPane' // Simplified z-index handling via Leaflet panes
          }}
        />
      ))}
    </>
  );
};
